"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/chat/route";
exports.ids = ["app/api/chat/route"];
exports.modules = {

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ "http":
/*!***********************!*\
  !*** external "http" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("http");

/***/ }),

/***/ "https":
/*!************************!*\
  !*** external "https" ***!
  \************************/
/***/ ((module) => {

module.exports = require("https");

/***/ }),

/***/ "node:fs":
/*!**************************!*\
  !*** external "node:fs" ***!
  \**************************/
/***/ ((module) => {

module.exports = require("node:fs");

/***/ }),

/***/ "node:stream":
/*!******************************!*\
  !*** external "node:stream" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("node:stream");

/***/ }),

/***/ "node:stream/web":
/*!**********************************!*\
  !*** external "node:stream/web" ***!
  \**********************************/
/***/ ((module) => {

module.exports = require("node:stream/web");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ "punycode":
/*!***************************!*\
  !*** external "punycode" ***!
  \***************************/
/***/ ((module) => {

module.exports = require("punycode");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("util");

/***/ }),

/***/ "worker_threads":
/*!*********************************!*\
  !*** external "worker_threads" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("worker_threads");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("zlib");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fchat%2Froute&page=%2Fapi%2Fchat%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fchat%2Froute.js&appDir=C%3A%5CUsers%5CUSER%5Ccustomer-support-ai%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CUSER%5Ccustomer-support-ai&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fchat%2Froute&page=%2Fapi%2Fchat%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fchat%2Froute.js&appDir=C%3A%5CUsers%5CUSER%5Ccustomer-support-ai%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CUSER%5Ccustomer-support-ai&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   originalPathname: () => (/* binding */ originalPathname),\n/* harmony export */   patchFetch: () => (/* binding */ patchFetch),\n/* harmony export */   requestAsyncStorage: () => (/* binding */ requestAsyncStorage),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/app-route/module.compiled */ \"(rsc)/./node_modules/next/dist/server/future/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"(rsc)/./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/server/lib/patch-fetch */ \"(rsc)/./node_modules/next/dist/server/lib/patch-fetch.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var C_Users_USER_customer_support_ai_app_api_chat_route_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/api/chat/route.js */ \"(rsc)/./app/api/chat/route.js\");\n\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/chat/route\",\n        pathname: \"/api/chat\",\n        filename: \"route\",\n        bundlePath: \"app/api/chat/route\"\n    },\n    resolvedPagePath: \"C:\\\\Users\\\\USER\\\\customer-support-ai\\\\app\\\\api\\\\chat\\\\route.js\",\n    nextConfigOutput,\n    userland: C_Users_USER_customer_support_ai_app_api_chat_route_js__WEBPACK_IMPORTED_MODULE_3__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { requestAsyncStorage, staticGenerationAsyncStorage, serverHooks } = routeModule;\nconst originalPathname = \"/api/chat/route\";\nfunction patchFetch() {\n    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({\n        serverHooks,\n        staticGenerationAsyncStorage\n    });\n}\n\n\n//# sourceMappingURL=app-route.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIuanM/bmFtZT1hcHAlMkZhcGklMkZjaGF0JTJGcm91dGUmcGFnZT0lMkZhcGklMkZjaGF0JTJGcm91dGUmYXBwUGF0aHM9JnBhZ2VQYXRoPXByaXZhdGUtbmV4dC1hcHAtZGlyJTJGYXBpJTJGY2hhdCUyRnJvdXRlLmpzJmFwcERpcj1DJTNBJTVDVXNlcnMlNUNVU0VSJTVDY3VzdG9tZXItc3VwcG9ydC1haSU1Q2FwcCZwYWdlRXh0ZW5zaW9ucz10c3gmcGFnZUV4dGVuc2lvbnM9dHMmcGFnZUV4dGVuc2lvbnM9anN4JnBhZ2VFeHRlbnNpb25zPWpzJnJvb3REaXI9QyUzQSU1Q1VzZXJzJTVDVVNFUiU1Q2N1c3RvbWVyLXN1cHBvcnQtYWkmaXNEZXY9dHJ1ZSZ0c2NvbmZpZ1BhdGg9dHNjb25maWcuanNvbiZiYXNlUGF0aD0mYXNzZXRQcmVmaXg9Jm5leHRDb25maWdPdXRwdXQ9JnByZWZlcnJlZFJlZ2lvbj0mbWlkZGxld2FyZUNvbmZpZz1lMzAlM0QhIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFzRztBQUN2QztBQUNjO0FBQ2M7QUFDM0Y7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLGdIQUFtQjtBQUMzQztBQUNBLGNBQWMseUVBQVM7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLFlBQVk7QUFDWixDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0EsUUFBUSxpRUFBaUU7QUFDekU7QUFDQTtBQUNBLFdBQVcsNEVBQVc7QUFDdEI7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUN1SDs7QUFFdkgiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jdXN0b21lci1zdXBwb3J0LWFpLz9mNmJiIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFwcFJvdXRlUm91dGVNb2R1bGUgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9mdXR1cmUvcm91dGUtbW9kdWxlcy9hcHAtcm91dGUvbW9kdWxlLmNvbXBpbGVkXCI7XG5pbXBvcnQgeyBSb3V0ZUtpbmQgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9mdXR1cmUvcm91dGUta2luZFwiO1xuaW1wb3J0IHsgcGF0Y2hGZXRjaCBhcyBfcGF0Y2hGZXRjaCB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL2xpYi9wYXRjaC1mZXRjaFwiO1xuaW1wb3J0ICogYXMgdXNlcmxhbmQgZnJvbSBcIkM6XFxcXFVzZXJzXFxcXFVTRVJcXFxcY3VzdG9tZXItc3VwcG9ydC1haVxcXFxhcHBcXFxcYXBpXFxcXGNoYXRcXFxccm91dGUuanNcIjtcbi8vIFdlIGluamVjdCB0aGUgbmV4dENvbmZpZ091dHB1dCBoZXJlIHNvIHRoYXQgd2UgY2FuIHVzZSB0aGVtIGluIHRoZSByb3V0ZVxuLy8gbW9kdWxlLlxuY29uc3QgbmV4dENvbmZpZ091dHB1dCA9IFwiXCJcbmNvbnN0IHJvdXRlTW9kdWxlID0gbmV3IEFwcFJvdXRlUm91dGVNb2R1bGUoe1xuICAgIGRlZmluaXRpb246IHtcbiAgICAgICAga2luZDogUm91dGVLaW5kLkFQUF9ST1VURSxcbiAgICAgICAgcGFnZTogXCIvYXBpL2NoYXQvcm91dGVcIixcbiAgICAgICAgcGF0aG5hbWU6IFwiL2FwaS9jaGF0XCIsXG4gICAgICAgIGZpbGVuYW1lOiBcInJvdXRlXCIsXG4gICAgICAgIGJ1bmRsZVBhdGg6IFwiYXBwL2FwaS9jaGF0L3JvdXRlXCJcbiAgICB9LFxuICAgIHJlc29sdmVkUGFnZVBhdGg6IFwiQzpcXFxcVXNlcnNcXFxcVVNFUlxcXFxjdXN0b21lci1zdXBwb3J0LWFpXFxcXGFwcFxcXFxhcGlcXFxcY2hhdFxcXFxyb3V0ZS5qc1wiLFxuICAgIG5leHRDb25maWdPdXRwdXQsXG4gICAgdXNlcmxhbmRcbn0pO1xuLy8gUHVsbCBvdXQgdGhlIGV4cG9ydHMgdGhhdCB3ZSBuZWVkIHRvIGV4cG9zZSBmcm9tIHRoZSBtb2R1bGUuIFRoaXMgc2hvdWxkXG4vLyBiZSBlbGltaW5hdGVkIHdoZW4gd2UndmUgbW92ZWQgdGhlIG90aGVyIHJvdXRlcyB0byB0aGUgbmV3IGZvcm1hdC4gVGhlc2Vcbi8vIGFyZSB1c2VkIHRvIGhvb2sgaW50byB0aGUgcm91dGUuXG5jb25zdCB7IHJlcXVlc3RBc3luY1N0b3JhZ2UsIHN0YXRpY0dlbmVyYXRpb25Bc3luY1N0b3JhZ2UsIHNlcnZlckhvb2tzIH0gPSByb3V0ZU1vZHVsZTtcbmNvbnN0IG9yaWdpbmFsUGF0aG5hbWUgPSBcIi9hcGkvY2hhdC9yb3V0ZVwiO1xuZnVuY3Rpb24gcGF0Y2hGZXRjaCgpIHtcbiAgICByZXR1cm4gX3BhdGNoRmV0Y2goe1xuICAgICAgICBzZXJ2ZXJIb29rcyxcbiAgICAgICAgc3RhdGljR2VuZXJhdGlvbkFzeW5jU3RvcmFnZVxuICAgIH0pO1xufVxuZXhwb3J0IHsgcm91dGVNb2R1bGUsIHJlcXVlc3RBc3luY1N0b3JhZ2UsIHN0YXRpY0dlbmVyYXRpb25Bc3luY1N0b3JhZ2UsIHNlcnZlckhvb2tzLCBvcmlnaW5hbFBhdGhuYW1lLCBwYXRjaEZldGNoLCAgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YXBwLXJvdXRlLmpzLm1hcCJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fchat%2Froute&page=%2Fapi%2Fchat%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fchat%2Froute.js&appDir=C%3A%5CUsers%5CUSER%5Ccustomer-support-ai%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CUSER%5Ccustomer-support-ai&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(rsc)/./app/api/chat/route.js":
/*!*******************************!*\
  !*** ./app/api/chat/route.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   POST: () => (/* binding */ POST)\n/* harmony export */ });\n/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/server */ \"(rsc)/./node_modules/next/dist/api/server.js\");\n/* harmony import */ var openai__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! openai */ \"(rsc)/./node_modules/openai/index.mjs\");\n // Import NextResponse from Next.js for handling responses\n // Import OpenAI library for interacting with the OpenAI API\n// System prompt for the AI, providing guidelines on how to respond to users\nconst systemPrompt = `Role: You are a customer support AI for Ed, an educational organization dedicated to helping students across various fields and areas of study plan their academic routines, study independently outside of school, and prepare for entering the workforce.\r\n\r\nGoals:\r\n\r\nAssist Students: Provide clear, supportive, and personalized guidance to students on how to effectively plan their academic schedules, manage their study time, and set realistic goals.\r\nOffer Study Resources: Recommend study materials, tools, and resources tailored to the student's field of study and individual needs, encouraging self-directed learning.\r\nPrepare for the Workforce: Advise students on practical steps they can take to prepare for their careers, including building relevant skills, gaining work experience, and understanding industry expectations.\r\nResolve Queries Efficiently: Address any questions or concerns from students promptly and accurately, ensuring they feel supported and confident in their academic and career planning.\r\nMaintain Positive Tone: Always communicate in a positive, empathetic, and encouraging manner, fostering a supportive and motivating environment for students.\r\nPromote Engagement: Encourage students to stay engaged with their academic plans, participate in available programs, and seek further assistance whenever needed.\r\nGuidelines:\r\n\r\nPersonalization: Tailor your responses based on the student's specific field of study, academic level, and individual challenges or goals.\r\nClarity: Use clear, simple language to ensure all information is easily understood.\r\nResourcefulness: Suggest practical resources, tools, or strategies that students can implement immediately.\r\nProfessionalism: Maintain a professional yet friendly tone, ensuring students feel comfortable and valued.\r\nYour mission is to empower students to take control of their academic journeys and prepare for a successful transition into the professional world.`; // Replace with your own system prompt\nasync function POST(req) {\n    const openai = new openai__WEBPACK_IMPORTED_MODULE_1__[\"default\"]({\n        baseURL: \"https://openrouter.ai/api/v1\",\n        apiKey: process.env.OPENROUTER_API_KEY\n    });\n    const data = await req.json(); // Parse the JSON body of the incoming request\n    // Create a chat completion request to the OpenAI API\n    const completion = await openai.chat.completions.create({\n        messages: [\n            {\n                role: \"system\",\n                content: systemPrompt\n            },\n            ...data\n        ],\n        model: \"meta-llama/llama-3.1-8b-instruct:free\",\n        stream: true\n    });\n    // Create a ReadableStream to handle the streaming response\n    const stream = new ReadableStream({\n        async start (controller) {\n            const encoder = new TextEncoder(); // Create a TextEncoder to convert strings to Uint8Array\n            try {\n                // Iterate over the streamed chunks of the response\n                for await (const chunk of completion){\n                    const content = chunk.choices[0]?.delta?.content; // Extract the content from the chunk\n                    if (content) {\n                        const text = encoder.encode(content); // Encode the content to Uint8Array\n                        controller.enqueue(text); // Enqueue the encoded text to the stream\n                    }\n                }\n            } catch (err) {\n                controller.error(err); // Handle any errors that occur during streaming\n            } finally{\n                controller.close(); // Close the stream when done\n            }\n        }\n    });\n    return new next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse(stream); // Return the stream as the response\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9hcHAvYXBpL2NoYXQvcm91dGUuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQzBDLENBQUMsMERBQTBEO0FBQzFFLENBQUMsNERBQTREO0FBRXhGLDRFQUE0RTtBQUM1RSxNQUFNRSxlQUFlLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7bUpBZ0I2SCxDQUFDLEVBQUUsc0NBQXNDO0FBRXJMLGVBQWVDLEtBQUtDLEdBQUc7SUFDNUIsTUFBTUMsU0FBUyxJQUFJSiw4Q0FBTUEsQ0FBQztRQUN4QkssU0FBUztRQUNUQyxRQUFRQyxRQUFRQyxHQUFHLENBQUNDLGtCQUFrQjtJQUN4QztJQUVBLE1BQU1DLE9BQU8sTUFBTVAsSUFBSVEsSUFBSSxJQUFJLDhDQUE4QztJQUU3RSxxREFBcUQ7SUFDckQsTUFBTUMsYUFBYSxNQUFNUixPQUFPUyxJQUFJLENBQUNDLFdBQVcsQ0FBQ0MsTUFBTSxDQUFDO1FBQ3REQyxVQUFVO1lBQUM7Z0JBQUVDLE1BQU07Z0JBQVVDLFNBQVNqQjtZQUFhO2VBQU1TO1NBQUs7UUFDOURTLE9BQU87UUFDUEMsUUFBUTtJQUNWO0lBRUEsMkRBQTJEO0lBQzNELE1BQU1BLFNBQVMsSUFBSUMsZUFBZTtRQUNoQyxNQUFNQyxPQUFNQyxVQUFVO1lBQ3BCLE1BQU1DLFVBQVUsSUFBSUMsZUFBZSx3REFBd0Q7WUFDM0YsSUFBSTtnQkFDRixtREFBbUQ7Z0JBQ25ELFdBQVcsTUFBTUMsU0FBU2QsV0FBWTtvQkFDcEMsTUFBTU0sVUFBVVEsTUFBTUMsT0FBTyxDQUFDLEVBQUUsRUFBRUMsT0FBT1YsU0FBUyxxQ0FBcUM7b0JBQ3ZGLElBQUlBLFNBQVM7d0JBQ1gsTUFBTVcsT0FBT0wsUUFBUU0sTUFBTSxDQUFDWixVQUFVLG1DQUFtQzt3QkFDekVLLFdBQVdRLE9BQU8sQ0FBQ0YsT0FBTyx5Q0FBeUM7b0JBQ3JFO2dCQUNGO1lBQ0YsRUFBRSxPQUFPRyxLQUFLO2dCQUNaVCxXQUFXVSxLQUFLLENBQUNELE1BQU0sZ0RBQWdEO1lBQ3pFLFNBQVU7Z0JBQ1JULFdBQVdXLEtBQUssSUFBSSw2QkFBNkI7WUFDbkQ7UUFDRjtJQUNGO0lBRUEsT0FBTyxJQUFJbkMscURBQVlBLENBQUNxQixTQUFTLG9DQUFvQztBQUN2RSIsInNvdXJjZXMiOlsid2VicGFjazovL2N1c3RvbWVyLXN1cHBvcnQtYWkvLi9hcHAvYXBpL2NoYXQvcm91dGUuanM/ZmVmZCJdLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaW1wb3J0IHsgTmV4dFJlc3BvbnNlIH0gZnJvbSAnbmV4dC9zZXJ2ZXInIC8vIEltcG9ydCBOZXh0UmVzcG9uc2UgZnJvbSBOZXh0LmpzIGZvciBoYW5kbGluZyByZXNwb25zZXNcclxuaW1wb3J0IE9wZW5BSSBmcm9tICdvcGVuYWknIC8vIEltcG9ydCBPcGVuQUkgbGlicmFyeSBmb3IgaW50ZXJhY3Rpbmcgd2l0aCB0aGUgT3BlbkFJIEFQSVxyXG5cclxuLy8gU3lzdGVtIHByb21wdCBmb3IgdGhlIEFJLCBwcm92aWRpbmcgZ3VpZGVsaW5lcyBvbiBob3cgdG8gcmVzcG9uZCB0byB1c2Vyc1xyXG5jb25zdCBzeXN0ZW1Qcm9tcHQgPSBgUm9sZTogWW91IGFyZSBhIGN1c3RvbWVyIHN1cHBvcnQgQUkgZm9yIEVkLCBhbiBlZHVjYXRpb25hbCBvcmdhbml6YXRpb24gZGVkaWNhdGVkIHRvIGhlbHBpbmcgc3R1ZGVudHMgYWNyb3NzIHZhcmlvdXMgZmllbGRzIGFuZCBhcmVhcyBvZiBzdHVkeSBwbGFuIHRoZWlyIGFjYWRlbWljIHJvdXRpbmVzLCBzdHVkeSBpbmRlcGVuZGVudGx5IG91dHNpZGUgb2Ygc2Nob29sLCBhbmQgcHJlcGFyZSBmb3IgZW50ZXJpbmcgdGhlIHdvcmtmb3JjZS5cclxuXHJcbkdvYWxzOlxyXG5cclxuQXNzaXN0IFN0dWRlbnRzOiBQcm92aWRlIGNsZWFyLCBzdXBwb3J0aXZlLCBhbmQgcGVyc29uYWxpemVkIGd1aWRhbmNlIHRvIHN0dWRlbnRzIG9uIGhvdyB0byBlZmZlY3RpdmVseSBwbGFuIHRoZWlyIGFjYWRlbWljIHNjaGVkdWxlcywgbWFuYWdlIHRoZWlyIHN0dWR5IHRpbWUsIGFuZCBzZXQgcmVhbGlzdGljIGdvYWxzLlxyXG5PZmZlciBTdHVkeSBSZXNvdXJjZXM6IFJlY29tbWVuZCBzdHVkeSBtYXRlcmlhbHMsIHRvb2xzLCBhbmQgcmVzb3VyY2VzIHRhaWxvcmVkIHRvIHRoZSBzdHVkZW50J3MgZmllbGQgb2Ygc3R1ZHkgYW5kIGluZGl2aWR1YWwgbmVlZHMsIGVuY291cmFnaW5nIHNlbGYtZGlyZWN0ZWQgbGVhcm5pbmcuXHJcblByZXBhcmUgZm9yIHRoZSBXb3JrZm9yY2U6IEFkdmlzZSBzdHVkZW50cyBvbiBwcmFjdGljYWwgc3RlcHMgdGhleSBjYW4gdGFrZSB0byBwcmVwYXJlIGZvciB0aGVpciBjYXJlZXJzLCBpbmNsdWRpbmcgYnVpbGRpbmcgcmVsZXZhbnQgc2tpbGxzLCBnYWluaW5nIHdvcmsgZXhwZXJpZW5jZSwgYW5kIHVuZGVyc3RhbmRpbmcgaW5kdXN0cnkgZXhwZWN0YXRpb25zLlxyXG5SZXNvbHZlIFF1ZXJpZXMgRWZmaWNpZW50bHk6IEFkZHJlc3MgYW55IHF1ZXN0aW9ucyBvciBjb25jZXJucyBmcm9tIHN0dWRlbnRzIHByb21wdGx5IGFuZCBhY2N1cmF0ZWx5LCBlbnN1cmluZyB0aGV5IGZlZWwgc3VwcG9ydGVkIGFuZCBjb25maWRlbnQgaW4gdGhlaXIgYWNhZGVtaWMgYW5kIGNhcmVlciBwbGFubmluZy5cclxuTWFpbnRhaW4gUG9zaXRpdmUgVG9uZTogQWx3YXlzIGNvbW11bmljYXRlIGluIGEgcG9zaXRpdmUsIGVtcGF0aGV0aWMsIGFuZCBlbmNvdXJhZ2luZyBtYW5uZXIsIGZvc3RlcmluZyBhIHN1cHBvcnRpdmUgYW5kIG1vdGl2YXRpbmcgZW52aXJvbm1lbnQgZm9yIHN0dWRlbnRzLlxyXG5Qcm9tb3RlIEVuZ2FnZW1lbnQ6IEVuY291cmFnZSBzdHVkZW50cyB0byBzdGF5IGVuZ2FnZWQgd2l0aCB0aGVpciBhY2FkZW1pYyBwbGFucywgcGFydGljaXBhdGUgaW4gYXZhaWxhYmxlIHByb2dyYW1zLCBhbmQgc2VlayBmdXJ0aGVyIGFzc2lzdGFuY2Ugd2hlbmV2ZXIgbmVlZGVkLlxyXG5HdWlkZWxpbmVzOlxyXG5cclxuUGVyc29uYWxpemF0aW9uOiBUYWlsb3IgeW91ciByZXNwb25zZXMgYmFzZWQgb24gdGhlIHN0dWRlbnQncyBzcGVjaWZpYyBmaWVsZCBvZiBzdHVkeSwgYWNhZGVtaWMgbGV2ZWwsIGFuZCBpbmRpdmlkdWFsIGNoYWxsZW5nZXMgb3IgZ29hbHMuXHJcbkNsYXJpdHk6IFVzZSBjbGVhciwgc2ltcGxlIGxhbmd1YWdlIHRvIGVuc3VyZSBhbGwgaW5mb3JtYXRpb24gaXMgZWFzaWx5IHVuZGVyc3Rvb2QuXHJcblJlc291cmNlZnVsbmVzczogU3VnZ2VzdCBwcmFjdGljYWwgcmVzb3VyY2VzLCB0b29scywgb3Igc3RyYXRlZ2llcyB0aGF0IHN0dWRlbnRzIGNhbiBpbXBsZW1lbnQgaW1tZWRpYXRlbHkuXHJcblByb2Zlc3Npb25hbGlzbTogTWFpbnRhaW4gYSBwcm9mZXNzaW9uYWwgeWV0IGZyaWVuZGx5IHRvbmUsIGVuc3VyaW5nIHN0dWRlbnRzIGZlZWwgY29tZm9ydGFibGUgYW5kIHZhbHVlZC5cclxuWW91ciBtaXNzaW9uIGlzIHRvIGVtcG93ZXIgc3R1ZGVudHMgdG8gdGFrZSBjb250cm9sIG9mIHRoZWlyIGFjYWRlbWljIGpvdXJuZXlzIGFuZCBwcmVwYXJlIGZvciBhIHN1Y2Nlc3NmdWwgdHJhbnNpdGlvbiBpbnRvIHRoZSBwcm9mZXNzaW9uYWwgd29ybGQuYDsgLy8gUmVwbGFjZSB3aXRoIHlvdXIgb3duIHN5c3RlbSBwcm9tcHRcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBQT1NUKHJlcSkge1xyXG4gIGNvbnN0IG9wZW5haSA9IG5ldyBPcGVuQUkoe1xyXG4gICAgYmFzZVVSTDogXCJodHRwczovL29wZW5yb3V0ZXIuYWkvYXBpL3YxXCIsXHJcbiAgICBhcGlLZXk6IHByb2Nlc3MuZW52Lk9QRU5ST1VURVJfQVBJX0tFWSwgLy8gVXNlIHRoZSBBUEkga2V5IGZyb20gZW52aXJvbm1lbnQgdmFyaWFibGVzXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGRhdGEgPSBhd2FpdCByZXEuanNvbigpOyAvLyBQYXJzZSB0aGUgSlNPTiBib2R5IG9mIHRoZSBpbmNvbWluZyByZXF1ZXN0XHJcblxyXG4gIC8vIENyZWF0ZSBhIGNoYXQgY29tcGxldGlvbiByZXF1ZXN0IHRvIHRoZSBPcGVuQUkgQVBJXHJcbiAgY29uc3QgY29tcGxldGlvbiA9IGF3YWl0IG9wZW5haS5jaGF0LmNvbXBsZXRpb25zLmNyZWF0ZSh7XHJcbiAgICBtZXNzYWdlczogW3sgcm9sZTogJ3N5c3RlbScsIGNvbnRlbnQ6IHN5c3RlbVByb21wdCB9LCAuLi5kYXRhXSwgLy8gSW5jbHVkZSB0aGUgc3lzdGVtIHByb21wdCBhbmQgdXNlciBtZXNzYWdlc1xyXG4gICAgbW9kZWw6IFwibWV0YS1sbGFtYS9sbGFtYS0zLjEtOGItaW5zdHJ1Y3Q6ZnJlZVwiLCAvLyBTcGVjaWZ5IHRoZSBtb2RlbCB0byB1c2VcclxuICAgIHN0cmVhbTogdHJ1ZSwgLy8gRW5hYmxlIHN0cmVhbWluZyByZXNwb25zZXNcclxuICB9KTtcclxuXHJcbiAgLy8gQ3JlYXRlIGEgUmVhZGFibGVTdHJlYW0gdG8gaGFuZGxlIHRoZSBzdHJlYW1pbmcgcmVzcG9uc2VcclxuICBjb25zdCBzdHJlYW0gPSBuZXcgUmVhZGFibGVTdHJlYW0oe1xyXG4gICAgYXN5bmMgc3RhcnQoY29udHJvbGxlcikge1xyXG4gICAgICBjb25zdCBlbmNvZGVyID0gbmV3IFRleHRFbmNvZGVyKCk7IC8vIENyZWF0ZSBhIFRleHRFbmNvZGVyIHRvIGNvbnZlcnQgc3RyaW5ncyB0byBVaW50OEFycmF5XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgLy8gSXRlcmF0ZSBvdmVyIHRoZSBzdHJlYW1lZCBjaHVua3Mgb2YgdGhlIHJlc3BvbnNlXHJcbiAgICAgICAgZm9yIGF3YWl0IChjb25zdCBjaHVuayBvZiBjb21wbGV0aW9uKSB7XHJcbiAgICAgICAgICBjb25zdCBjb250ZW50ID0gY2h1bmsuY2hvaWNlc1swXT8uZGVsdGE/LmNvbnRlbnQ7IC8vIEV4dHJhY3QgdGhlIGNvbnRlbnQgZnJvbSB0aGUgY2h1bmtcclxuICAgICAgICAgIGlmIChjb250ZW50KSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHRleHQgPSBlbmNvZGVyLmVuY29kZShjb250ZW50KTsgLy8gRW5jb2RlIHRoZSBjb250ZW50IHRvIFVpbnQ4QXJyYXlcclxuICAgICAgICAgICAgY29udHJvbGxlci5lbnF1ZXVlKHRleHQpOyAvLyBFbnF1ZXVlIHRoZSBlbmNvZGVkIHRleHQgdG8gdGhlIHN0cmVhbVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgY29udHJvbGxlci5lcnJvcihlcnIpOyAvLyBIYW5kbGUgYW55IGVycm9ycyB0aGF0IG9jY3VyIGR1cmluZyBzdHJlYW1pbmdcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBjb250cm9sbGVyLmNsb3NlKCk7IC8vIENsb3NlIHRoZSBzdHJlYW0gd2hlbiBkb25lXHJcbiAgICAgIH1cclxuICAgIH0sXHJcbiAgfSk7XHJcblxyXG4gIHJldHVybiBuZXcgTmV4dFJlc3BvbnNlKHN0cmVhbSk7IC8vIFJldHVybiB0aGUgc3RyZWFtIGFzIHRoZSByZXNwb25zZVxyXG59XHJcbiJdLCJuYW1lcyI6WyJOZXh0UmVzcG9uc2UiLCJPcGVuQUkiLCJzeXN0ZW1Qcm9tcHQiLCJQT1NUIiwicmVxIiwib3BlbmFpIiwiYmFzZVVSTCIsImFwaUtleSIsInByb2Nlc3MiLCJlbnYiLCJPUEVOUk9VVEVSX0FQSV9LRVkiLCJkYXRhIiwianNvbiIsImNvbXBsZXRpb24iLCJjaGF0IiwiY29tcGxldGlvbnMiLCJjcmVhdGUiLCJtZXNzYWdlcyIsInJvbGUiLCJjb250ZW50IiwibW9kZWwiLCJzdHJlYW0iLCJSZWFkYWJsZVN0cmVhbSIsInN0YXJ0IiwiY29udHJvbGxlciIsImVuY29kZXIiLCJUZXh0RW5jb2RlciIsImNodW5rIiwiY2hvaWNlcyIsImRlbHRhIiwidGV4dCIsImVuY29kZSIsImVucXVldWUiLCJlcnIiLCJlcnJvciIsImNsb3NlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./app/api/chat/route.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/formdata-node","vendor-chunks/openai","vendor-chunks/form-data-encoder","vendor-chunks/whatwg-url","vendor-chunks/agentkeepalive","vendor-chunks/tr46","vendor-chunks/web-streams-polyfill","vendor-chunks/node-fetch","vendor-chunks/webidl-conversions","vendor-chunks/ms","vendor-chunks/humanize-ms","vendor-chunks/event-target-shim","vendor-chunks/abort-controller"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fchat%2Froute&page=%2Fapi%2Fchat%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fchat%2Froute.js&appDir=C%3A%5CUsers%5CUSER%5Ccustomer-support-ai%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CUSER%5Ccustomer-support-ai&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();